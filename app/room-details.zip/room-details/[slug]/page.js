export default function RoomDetails({ params }) {
  const { slug } = params;
  return (
    <div style={{ padding: '3rem 1rem', maxWidth: 700, margin: '0 auto' }}>
      <h1 style={{ fontSize: '2.2rem', color: '#b8860b', marginBottom: '1.5rem' }}>Room Details: {slug.charAt(0).toUpperCase() + slug.slice(1)}</h1>
      <p style={{ fontSize: '1.1rem', color: '#444' }}>
        This is a placeholder for the <b>{slug}</b> room details page.<br/>
        You can fetch and display more details here based on the slug.
      </p>
    </div>
  );
} 